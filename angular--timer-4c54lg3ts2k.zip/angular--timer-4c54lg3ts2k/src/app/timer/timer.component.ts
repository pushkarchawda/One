import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'timer',
  templateUrl: './timer.component.html',
})
export class TimerComponent {

  started: boolean;
  minutes: number;
  seconds: number;
  newMin: number;
  interval: any;

  constructor() {
  }

  resetVariables(mins, secs, started) {
    
  }

  start() {
    
  }
                                                                      
  addFive() {
    
  }

  minusFive() {
    
  }


  stop() {
    
  }

  intervalCallback() {
    
  }

}
