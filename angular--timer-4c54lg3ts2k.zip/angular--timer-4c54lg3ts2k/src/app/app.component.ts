import { Component } from '@angular/core';

@Component({
  selector: 'app',
})
export class AppComponent {}
